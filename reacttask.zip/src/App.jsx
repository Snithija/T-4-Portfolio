import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Portfolio from "./pages/Portfolio";
// import About from "./pages/About";
import About from'./pages/About';
 

function App() {
  
  return (
    <Routes>
      <Route path="/" element={<Portfolio />} />
      <Route path="/about" element={<About />} />
      <Route path="/projects" element={<Portfolio />} />
    </Routes>
  );
}

export default App;
